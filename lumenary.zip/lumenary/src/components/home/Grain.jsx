
export default function Grain() {
  return <div className="grain" aria-hidden="true" />;
}
